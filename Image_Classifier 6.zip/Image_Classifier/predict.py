import torch
from torch import nn
from torch import optim
from torchvision import datasets, models, transforms
import torch.nn.functional as F
import torch.utils.data
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from collections import OrderedDict
from PIL import Image
import argparse
import json

parser = argparse.ArgumentParser (description = "predict")

parser.add_argument ('image_dir', help = 'directory for image', type = str)
parser.add_argument ('load_dir', help = 'directory for the checkpoint', type = str)
parser.add_argument ('--category_names', help = 'mapping of categories', default = 'cat_to_name.json', type = str)
parser.add_argument ('--top_k', help = 'top k', default = 1, type = int)
parser.add_argument ('--GPU', help = "GPU or no", default = 'cpu', type = str)

args = parser.parse_args()

device = ''
if args.GPU == 'GPU':
    device = 'cuda'
else:
    device = 'cpu'
    
def loading(file_path):
    checkpoint = torch.load (file_path) 
    model = models.vgg16(pretrained='True')

    model.classifier = checkpoint ['classifier']
    model.class_to_idx = checkpoint ['mapping']
    model.load_state_dict(checkpoint ['state_dict'])

    for param in model.parameters():
        param.requires_grad = False

    return model

#same as in python notebook
def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    img = Image.open(image)

    size = 256
    img.thumbnail((size, size))

    width, height = img.size
    left = (width - 244) / 2
    top = (height - 244) / 2
    right = left + 244
    bottom = top + 244
    img = img.crop((left, top, right, bottom))

    numpy_img = np.array(img) / 255

    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    numpy_img = (numpy_img - mean) / std

    numpy_img = numpy_img.transpose(2, 0, 1)

    tensor_img = torch.tensor(numpy_img, dtype=torch.float32)

    return tensor_img


#same as in python notebook
def predict(image_path, model, top_k=5):
    model.eval()

    device = torch.device("cpu")
    model = model.to(device)

    i = process_image(image_path)
    i = torch.tensor(i, dtype=torch.float).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(i)

    prob, indices = torch.topk(torch.softmax(output, dim=1), top_k)
    prob = prob.squeeze().tolist()
    indices = indices.squeeze().tolist()

    idx_class = {idx: class_ for class_, idx in model.class_to_idx.items()}
    labels = [idx_class[idx] for idx in indices]

    flower = [cat_to_name[label] for label in labels]

    return prob, labels, flower


with open(args.category_names, 'r') as f:
     cat_to_name = json.load(f)
        
topk = args.top_k

model = loading(args.load_dir)

path = args.image_dir

prob, label, flower = predict(path, model, topk)

for i in range(topk):
    print('Label',label[i])
    print('Flower',flower[i])
    x = prob[i]
    x = x * 100
    print('Probability',prob[i])
 
    