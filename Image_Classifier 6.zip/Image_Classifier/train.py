import argparse
import torch
from torch import nn
from torch import optim
from collections import OrderedDict
from torchvision import datasets, transforms, models
import json

parser = argparse.ArgumentParser(description='train')

parser.add_argument ('--data_dir', help = 'Need to Provide data dir', default = 'flowers', type = str)
parser.add_argument ('--save_dir', help = 'Provide save dir', type = str)
parser.add_argument ('--lrn', help = 'Learning rate', default = 0.001, type = float)
parser.add_argument ('--arch', help = 'model to be used, which is vgg16', default = 'vgg16', type = str)
parser.add_argument ('--hidden_units', help = 'hidden units in layers', type = int)
parser.add_argument ('--epochs', help = 'epochs', default = 11, type = int)
parser.add_argument ('--GPU', help = "GPU or no", type = str)

args = parser.parse_args ()

data_dir = args.data_dir
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'

with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)

device = ''
if args.GPU is not None and args.GPU == 'GPU':
    device = 'cuda'
else:
    device = 'cpu'


#new data transforms for the given data directory, so code is same as the one in python notebook
data_transforms = { 
    'train': transforms.Compose([
        transforms.RandomResizedCrop(size=224),
        transforms.RandomHorizontalFlip(),
        transforms.Normalize([0.485,0.456,0.406],
                             [0.229,0.224,0.225])
    ]),
    
    'test': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.Normalize([0.485,0.456,0.406],
                             [0.229,0.224,0.225])
    ]),
    'valid': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.Normalize([0.485,0.456,0.406],
                           [0.229,0.224,0.225])
    ])
}

train_image_datasets = datasets.ImageFolder(train_dir, transform = data_transforms['train'])
test_image_datasets = datasets.ImageFolder(test_dir, transform = data_transforms['test'])
valid_image_datasets = datasets.ImageFolder(valid_dir, transform = data_transforms['valid'])


train_loader = torch.utils.data.DataLoader(train_image_datasets, batch_size=64, shuffle = True)
test_loader = torch.utils.data.DataLoader(test_image_datasets, batch_size = 64, shuffle = True)
valid_loader = torch.utils.data.DataLoader(valid_image_datasets, batch_size =64, shuffle = True)

def load_model (arch, hidden_units):
    
     model = models.vgg16(pretrained=True)
        
     for param in model.parameters():
         param.requires_grad = False
            
     if hidden_units is not None:
        classifier = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(25088, 4096)), 
            ('relu1', nn.ReLU()),
            ('dropout',nn.Dropout(0.25)), 
            ('fc2', nn.Linear(4096, hidden_units)), 
            ('relu2',nn.ReLU()),
            ('fc3',nn.Linear(hidden_units,512)), 
            ('relu3',nn.ReLU()),
            ('fc4',nn.Linear(512,102)),
            ('output', nn.LogSoftmax(dim=1))]))
     else: 
        classifier = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(25088, 4096)), 
            ('relu1', nn.ReLU()),
            ('dropout',nn.Dropout(0.25)), 
            ('fc2', nn.Linear(4096, 2048)), 
            ('relu2',nn.ReLU()),
            ('fc3',nn.Linear(2048,512)), 
            ('relu3',nn.ReLU()),
            ('fc4',nn.Linear(512,102)),
            ('output', nn.LogSoftmax(dim=1))]))
            
     model.classifier = classifier   
     return model, arch
    

def validation(model, criterion, valid_loader):
    acc = 0
    valid_l = 0
    
    model.to(device)

    for inputs, labels in valid_loader:
        inputs = inputs.to(device)
        labels = labels.to(device)
        output = model.forward(inputs)
        valid_l += criterion(output, labels).item()

        ps = torch.exp(output)
        eq = (labels.data == ps.max(dim=1)[1])
        acc += eq.type(torch.FloatTensor).mean()

    return valid_l, acc     

model,arch = load_model('vgg16', args.hidden_units)

optimizer = optim.Adam(model.classifier.parameters(), lr = args.lrn)
criterion = nn.NLLLoss()
model.to(device)
epochs = args.epochs

#same training as in python notebook
for epoch in range(epochs):
    print('Epoch',epoch + 1,'/',epochs)
    model.train()
   
    train_l = 0.0
    train_acc = 0.0
    valid_l = 0.0
    valid_acc = 0.0
 
    for i, (inputs, labels) in enumerate(train_loader):
        inputs = inputs.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        train_l += loss.item() * inputs.size(0)
        ret, predictions = torch.max(outputs.data, 1)
        correct_counts = predictions.eq(labels.data.view_as(predictions))
        acc = torch.mean(correct_counts.type(torch.FloatTensor))
        train_acc += acc.item() * inputs.size(0)
         
        print("Batch no:",i," Loss on training",loss.item(),"Accuracy:",acc.item())
       
model.class_to_idx = train_image_datasets.class_to_idx

check = ({'structure' :'alexnet',
            'hidden_layer1':4096,
            'epochs':11,
            'dropout':0.25,
            'class_to_idx':model.class_to_idx,
            'state_dict':model.state_dict(),
            'optimizer_dict':optimizer.state_dict()},
            'checkpoint.pth')

if args.save_dir is True:
    torch.save(check, args.save_dir + '/checkpoint.pth')
else:
    torch.save(check, 'checkpoint.pth')

#Train.py complete